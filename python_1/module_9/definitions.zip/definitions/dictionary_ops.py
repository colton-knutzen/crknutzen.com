def print_dict(dictionary):
    for key, value in dictionary.items():
        print(key, value)
