def print_set(set):
    for value in set:
        print(value)