def greeting():
    print("Hello")


def message():
    print("Author: Colton")